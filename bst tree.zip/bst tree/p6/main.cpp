//write a function to calculate the summation of a BST element(Binary search tree)
#include <iostream>

using namespace std;

// Definition for a binary tree node.
struct TreeNode {
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(int x) : val(x), left(NULL), right(NULL) {}
};

// Function to insert a node into BST
TreeNode* insert(TreeNode* root, int key) {
    if (root == NULL) {
        return new TreeNode(key);
    }

    if (key < root->val) {
        root->left = insert(root->left, key);
    } else if (key > root->val) {
        root->right = insert(root->right, key);
    }

    return root;
}

// Function to calculate the sum of all elements in BST
int sumBST(TreeNode* root) {
    if (root == NULL) {
        return 0;
    }
    return root->val + sumBST(root->left) + sumBST(root->right);
}

int main() {
    // Example usage
    TreeNode* root = NULL;
    int keys[] = {10, 5, 15, 3, 7, 13, 18};
    for (int key : keys) {
        root = insert(root, key);
    }

    int totalSum = sumBST(root);
    cout << "Sum of elements in BST: " << totalSum << endl;

    return 0;
}

